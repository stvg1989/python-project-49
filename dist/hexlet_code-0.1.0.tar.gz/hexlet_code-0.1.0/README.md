### Hexlet tests and linter status:
[![Actions Status](https://github.com/stvg1989/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/stvg1989/python-project-49/actions)